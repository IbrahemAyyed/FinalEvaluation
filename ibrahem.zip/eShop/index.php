<?php
    require_once("inc/header.php");

    $page = "Welcome on MyEshop.com"
?>

        <h1><?= $page ?></h1>
        <p class="lead">Please feel free to buy a lot of stuff and spend all of your money. Ki$$e$ !</p>
    
<?php
    require_once("inc/footer.php");
?>